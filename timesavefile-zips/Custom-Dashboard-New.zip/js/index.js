// dropDownForm 
var HeadingDropDown = document.querySelector('.dropDwon-Heading');

HeadingDropDown.addEventListener('click', function () {

  var arrowHeading = this.querySelector('.arrowicon');
    arrowHeading.classList.toggle('active');

  var nextSibling = this.nextElementSibling;
    nextSibling.classList.toggle('active')
})
// dropDownForm 

  // dashboard menu and submenu 
var menuItems = document.querySelectorAll('#menu > li');

for (var i = 0; i < menuItems.length; i++) {
    menuItems[i].addEventListener('click', function() {
        var isActive = this.classList.contains('active');

        menuItems.forEach(function(item) {
            item.classList.remove('active');
        });

        var submenus = document.querySelectorAll('.submenu');
        submenus.forEach(function(submenu) {
            submenu.classList.remove('active');
        });
        if (!isActive) {
            this.classList.add('active');

            var submenu = this.querySelector('.submenu');
            if (submenu) {
                submenu.classList.add('active');
            }
        }
    });
}
// dashboard menu and submenu 

  
  let jsonData = [
    {
        "name": "Ascension Island",
        "code": "AC",
        "image": "./images/country_flags/AC.svg"
    },
    {
        "name": "Andorra",
        "code": "AD",
        "image": "./images/country_flags/AD.svg"
    },
    {
        "name": "United Arab Emirates",
        "code": "AE",
        "image": "./images/country_flags/AE.svg"
    },
    {
        "name": "Afghanistan",
        "code": "AF",
        "image": "./images/country_flags/AF.svg"
    },
    {
        "name": "Antigua & Barbuda",
        "code": "AG",
        "image": "./images/country_flags/AG.svg"
    },
    {
        "name": "Anguilla",
        "code": "AI",
        "image": "./images/country_flags/AI.svg"
    },
    {
        "name": "Albania",
        "code": "AL",
        "image": "./images/country_flags/AL.svg"
    },
    {
        "name": "Armenia",
        "code": "AM",
        "image": "./images/country_flags/AM.svg"
    },
    {
        "name": "Angola",
        "code": "AO",
        "image": "./images/country_flags/AO.svg"
    },
    {
        "name": "Antarctica",
        "code": "AQ",
        "image": "./images/country_flags/AQ.svg"
    },
    {
        "name": "Argentina",
        "code": "AR",
        "image": "./images/country_flags/AR.svg"
    },
    {
        "name": "American Samoa",
        "code": "AS",
        "image": "./images/country_flags/AS.svg"
    },
    {
        "name": "Austria",
        "code": "AT",
        "image": "./images/country_flags/AT.svg"
    },
    {
        "name": "Australia",
        "code": "AU",
        "image": "./images/country_flags/AU.svg"
    },
    {
        "name": "Aruba",
        "code": "AW",
        "image": "./images/country_flags/AW.svg"
    },
    {
        "name": "Åland Islands",
        "code": "AX",
        "image": "./images/country_flags/AX.svg"
    },
    {
        "name": "Azerbaijan",
        "code": "AZ",
        "image": "./images/country_flags/AZ.svg"
    },
    {
        "name": "Bosnia & Herzegovina",
        "code": "BA",
        "image": "./images/country_flags/BA.svg"
    },
    {
        "name": "Barbados",
        "code": "BB",
        "image": "./images/country_flags/BB.svg"
    },
    {
        "name": "Bangladesh",
        "code": "BD",
        "image": "./images/country_flags/BD.svg"
    },
    {
        "name": "Belgium",
        "code": "BE",
        "image": "./images/country_flags/BE.svg"
    },
    {
        "name": "Burkina Faso",
        "code": "BF",
        "image": "./images/country_flags/BF.svg"
    },
    {
        "name": "Bulgaria",
        "code": "BG",
        "image": "./images/country_flags/BG.svg"
    },
    {
        "name": "Bahrain",
        "code": "BH",
        "image": "./images/country_flags/BH.svg"
    },
    {
        "name": "Burundi",
        "code": "BI",
        "image": "./images/country_flags/BI.svg"
    },
    {
        "name": "Benin",
        "code": "BJ",
        "image": "./images/country_flags/BJ.svg"
    },
    {
        "name": "St. Barthélemy",
        "code": "BL",
        "image": "./images/country_flags/BL.svg"
    },
    {
        "name": "Bermuda",
        "code": "BM",
        "image": "./images/country_flags/BM.svg"
    },
    {
        "name": "Brunei",
        "code": "BN",
        "image": "./images/country_flags/BN.svg"
    },
    {
        "name": "Bolivia",
        "code": "BO",
        "image": "./images/country_flags/BO.svg"
    },
    {
        "name": "Caribbean Netherlands",
        "code": "BQ",
        "image": "./images/country_flags/BQ.svg"
    },
    {
        "name": "Brazil",
        "code": "BR",
        "image": "./images/country_flags/BR.svg"
    },
    {
        "name": "Bahamas",
        "code": "BS",
        "image": "./images/country_flags/BS.svg"
    },
    {
        "name": "Bhutan",
        "code": "BT",
        "image": "./images/country_flags/BT.svg"
    },
    {
        "name": "Bouvet Island",
        "code": "BV",
        "image": "./images/country_flags/BV.svg"
    },
    {
        "name": "Botswana",
        "code": "BW",
        "image": "./images/country_flags/BW.svg"
    },
    {
        "name": "Belarus",
        "code": "BY",
        "image": "./images/country_flags/BY.svg"
    },
    {
        "name": "Belize",
        "code": "BZ",
        "image": "./images/country_flags/BZ.svg"
    },
    {
        "name": "Canada",
        "code": "CA",
        "image": "./images/country_flags/CA.svg"
    },
    {
        "name": "Cocos (Keeling) Islands",
        "code": "CC",
        "image": "./images/country_flags/CC.svg"
    },
    {
        "name": "Congo - Kinshasa",
        "code": "CD",
        "image": "./images/country_flags/CD.svg"
    },
    {
        "name": "Central African Republic",
        "code": "CF",
        "image": "./images/country_flags/CF.svg"
    },
    {
        "name": "Congo - Brazzaville",
        "code": "CG",
        "image": "./images/country_flags/CG.svg"
    },
    {
        "name": "Switzerland",
        "code": "CH",
        "image": "./images/country_flags/CH.svg"
    },
    {
        "name": "Côte d’Ivoire",
        "code": "CI",
        "image": "./images/country_flags/CI.svg"
    },
    {
        "name": "Cook Islands",
        "code": "CK",
        "image": "./images/country_flags/CK.svg"
    },
    {
        "name": "Chile",
        "code": "CL",
        "image": "./images/country_flags/CL.svg"
    },
    {
        "name": "Cameroon",
        "code": "CM",
        "image": "./images/country_flags/CM.svg"
    },
    {
        "name": "China",
        "code": "CN",
        "image": "./images/country_flags/CN.svg"
    },
    {
        "name": "Colombia",
        "code": "CO",
        "image": "./images/country_flags/CO.svg"
    },
    {
        "name": "Clipperton Island",
        "code": "CP",
        "image": "./images/country_flags/CP.svg"
    },
    {
        "name": "Costa Rica",
        "code": "CR",
        "image": "./images/country_flags/CR.svg"
    },
    {
        "name": "Cuba",
        "code": "CU",
        "image": "./images/country_flags/CU.svg"
    },
    {
        "name": "Cape Verde",
        "code": "CV",
        "image": "./images/country_flags/CV.svg"
    },
    {
        "name": "Curaçao",
        "code": "CW",
        "image": "./images/country_flags/CW.svg"
    },
    {
        "name": "Christmas Island",
        "code": "CX",
        "image": "./images/country_flags/CX.svg"
    },
    {
        "name": "Cyprus",
        "code": "CY",
        "image": "./images/country_flags/CY.svg"
    },
    {
        "name": "Czechia",
        "code": "CZ",
        "image": "./images/country_flags/CZ.svg"
    },
    {
        "name": "Germany",
        "code": "DE",
        "image": "./images/country_flags/DE.svg"
    },
    {
        "name": "Diego Garcia",
        "code": "DG",
        "image": "./images/country_flags/DG.svg"
    },
    {
        "name": "Djibouti",
        "code": "DJ",
        "image": "./images/country_flags/DJ.svg"
    },
    {
        "name": "Denmark",
        "code": "DK",
        "image": "./images/country_flags/DK.svg"
    },
    {
        "name": "Dominica",
        "code": "DM",
        "image": "./images/country_flags/DM.svg"
    },
    {
        "name": "Dominican Republic",
        "code": "DO",
        "image": "./images/country_flags/DO.svg"
    },
    {
        "name": "Algeria",
        "code": "DZ",
        "image": "./images/country_flags/DZ.svg"
    },
    {
        "name": "Ceuta & Melilla",
        "code": "EA",
        "image": "./images/country_flags/EA.svg"
    },
    {
        "name": "Ecuador",
        "code": "EC",
        "image": "./images/country_flags/EC.svg"
    },
    {
        "name": "Estonia",
        "code": "EE",
        "image": "./images/country_flags/EE.svg"
    },
    {
        "name": "Egypt",
        "code": "EG",
        "image": "./images/country_flags/EG.svg"
    },
    {
        "name": "Western Sahara",
        "code": "EH",
        "image": "./images/country_flags/EH.svg"
    },
    {
        "name": "Eritrea",
        "code": "ER",
        "image": "./images/country_flags/ER.svg"
    },
    {
        "name": "Spain",
        "code": "ES",
        "image": "./images/country_flags/ES.svg"
    },
    {
        "name": "Ethiopia",
        "code": "ET",
        "image": "./images/country_flags/ET.svg"
    },
    {
        "name": "European Union",
        "code": "EU",
        "image": "./images/country_flags/EU.svg"
    },
    {
        "name": "Finland",
        "code": "FI",
        "image": "./images/country_flags/FI.svg"
    },
    {
        "name": "Fiji",
        "code": "FJ",
        "image": "./images/country_flags/FJ.svg"
    },
    {
        "name": "Falkland Islands",
        "code": "FK",
        "image": "./images/country_flags/FK.svg"
    },
    {
        "name": "Micronesia",
        "code": "FM",
        "image": "./images/country_flags/FM.svg"
    },
    {
        "name": "Faroe Islands",
        "code": "FO",
        "image": "./images/country_flags/FO.svg"
    },
    {
        "name": "France",
        "code": "FR",
        "image": "./images/country_flags/FR.svg"
    },
    {
        "name": "Gabon",
        "code": "GA",
        "image": "./images/country_flags/GA.svg"
    },
    {
        "name": "United Kingdom",
        "code": "GB",
        "image": "./images/country_flags/GB.svg"
    },
    {
        "name": "Grenada",
        "code": "GD",
        "image": "./images/country_flags/GD.svg"
    },
    {
        "name": "Georgia",
        "code": "GE",
        "image": "./images/country_flags/GE.svg"
    },
    {
        "name": "French Guiana",
        "code": "GF",
        "image": "./images/country_flags/GF.svg"
    },
    {
        "name": "Guernsey",
        "code": "GG",
        "image": "./images/country_flags/GG.svg"
    },
    {
        "name": "Ghana",
        "code": "GH",
        "image": "./images/country_flags/GH.svg"
    },
    {
        "name": "Gibraltar",
        "code": "GI",
        "image": "./images/country_flags/GI.svg"
    },
    {
        "name": "Greenland",
        "code": "GL",
        "image": "./images/country_flags/GL.svg"
    },
    {
        "name": "Gambia",
        "code": "GM",
        "image": "./images/country_flags/GM.svg"
    },
    {
        "name": "Guinea",
        "code": "GN",
        "image": "./images/country_flags/GN.svg"
    },
    {
        "name": "Guadeloupe",
        "code": "GP",
        "image": "./images/country_flags/GP.svg"
    },
    {
        "name": "Equatorial Guinea",
        "code": "GQ",
        "image": "./images/country_flags/GQ.svg"
    },
    {
        "name": "Greece",
        "code": "GR",
        "image": "./images/country_flags/GR.svg"
    },
    {
        "name": "South Georgia & South Sandwich Islands",
        "code": "GS",
        "image": "./images/country_flags/GS.svg"
    },
    {
        "name": "Guatemala",
        "code": "GT",
        "image": "./images/country_flags/GT.svg"
    },
    {
        "name": "Guam",
        "code": "GU",
        "image": "./images/country_flags/GU.svg"
    },
    {
        "name": "Guinea-Bissau",
        "code": "GW",
        "image": "./images/country_flags/GW.svg"
    },
    {
        "name": "Guyana",
        "code": "GY",
        "image": "./images/country_flags/GY.svg"
    },
    {
        "name": "Hong Kong SAR China",
        "code": "HK",
        "image": "./images/country_flags/HK.svg"
    },
    {
        "name": "Heard & McDonald Islands",
        "code": "HM",
        "image": "./images/country_flags/HM.svg"
    },
    {
        "name": "Honduras",
        "code": "HN",
        "image": "./images/country_flags/HN.svg"
    },
    {
        "name": "Croatia",
        "code": "HR",
        "image": "./images/country_flags/HR.svg"
    },
    {
        "name": "Haiti",
        "code": "HT",
        "image": "./images/country_flags/HT.svg"
    },
    {
        "name": "Hungary",
        "code": "HU",
        "image": "./images/country_flags/HU.svg"
    },
    {
        "name": "Canary Islands",
        "code": "IC",
        "image": "./images/country_flags/IC.svg"
    },
    {
        "name": "Indonesia",
        "code": "ID",
        "image": "./images/country_flags/ID.svg"
    },
    {
        "name": "Ireland",
        "code": "IE",
        "image": "./images/country_flags/IE.svg"
    },
    {
        "name": "Israel",
        "code": "IL",
        "image": "./images/country_flags/IL.svg"
    },
    {
        "name": "Isle of Man",
        "code": "IM",
        "image": "./images/country_flags/IM.svg"
    },
    {
        "name": "India",
        "code": "IN",
        "image": "./images/country_flags/IN.svg"
    },
    {
        "name": "British Indian Ocean Territory",
        "code": "IO",
        "image": "./images/country_flags/IO.svg"
    },
    {
        "name": "Iraq",
        "code": "IQ",
        "image": "./images/country_flags/IQ.svg"
    },
    {
        "name": "Iran",
        "code": "IR",
        "image": "./images/country_flags/IR.svg"
    },
    {
        "name": "Iceland",
        "code": "IS",
        "image": "./images/country_flags/IS.svg"
    },
    {
        "name": "Italy",
        "code": "IT",
        "image": "./images/country_flags/IT.svg"
    },
    {
        "name": "Jersey",
        "code": "JE",
        "image": "./images/country_flags/JE.svg"
    },
    {
        "name": "Jamaica",
        "code": "JM",
        "image": "./images/country_flags/JM.svg"
    },
    {
        "name": "Jordan",
        "code": "JO",
        "image": "./images/country_flags/JO.svg"
    },
    {
        "name": "Japan",
        "code": "JP",
        "image": "./images/country_flags/JP.svg"
    },
    {
        "name": "Kenya",
        "code": "KE",
        "image": "./images/country_flags/KE.svg"
    },
    {
        "name": "Kyrgyzstan",
        "code": "KG",
        "image": "./images/country_flags/KG.svg"
    },
    {
        "name": "Cambodia",
        "code": "KH",
        "image": "./images/country_flags/KH.svg"
    },
    {
        "name": "Kiribati",
        "code": "KI",
        "image": "./images/country_flags/KI.svg"
    },
    {
        "name": "Comoros",
        "code": "KM",
        "image": "./images/country_flags/KM.svg"
    },
    {
        "name": "St. Kitts & Nevis",
        "code": "KN",
        "image": "./images/country_flags/KN.svg"
    },
    {
        "name": "North Korea",
        "code": "KP",
        "image": "./images/country_flags/KP.svg"
    },
    {
        "name": "South Korea",
        "code": "KR",
        "image": "./images/country_flags/KR.svg"
    },
    {
        "name": "Kuwait",
        "code": "KW",
        "image": "./images/country_flags/KW.svg"
    },
    {
        "name": "Cayman Islands",
        "code": "KY",
        "image": "./images/country_flags/KY.svg"
    },
    {
        "name": "Kazakhstan",
        "code": "KZ",
        "image": "./images/country_flags/KZ.svg"
    },
    {
        "name": "Laos",
        "code": "LA",
        "image": "./images/country_flags/LA.svg"
    },
    {
        "name": "Lebanon",
        "code": "LB",
        "image": "./images/country_flags/LB.svg"
    },
    {
        "name": "St. Lucia",
        "code": "LC",
        "image": "./images/country_flags/LC.svg"
    },
    {
        "name": "Liechtenstein",
        "code": "LI",
        "image": "./images/country_flags/LI.svg"
    },
    {
        "name": "Sri Lanka",
        "code": "LK",
        "image": "./images/country_flags/LK.svg"
    },
    {
        "name": "Liberia",
        "code": "LR",
        "image": "./images/country_flags/LR.svg"
    },
    {
        "name": "Lesotho",
        "code": "LS",
        "image": "./images/country_flags/LS.svg"
    },
    {
        "name": "Lithuania",
        "code": "LT",
        "image": "./images/country_flags/LT.svg"
    },
    {
        "name": "Luxembourg",
        "code": "LU",
        "image": "./images/country_flags/LU.svg"
    },
    {
        "name": "Latvia",
        "code": "LV",
        "image": "./images/country_flags/LV.svg"
    },
    {
        "name": "Libya",
        "code": "LY",
        "image": "./images/country_flags/LY.svg"
    },
    {
        "name": "Morocco",
        "code": "MA",
        "image": "./images/country_flags/MA.svg"
    },
    {
        "name": "Monaco",
        "code": "MC",
        "image": "./images/country_flags/MC.svg"
    },
    {
        "name": "Moldova",
        "code": "MD",
        "image": "./images/country_flags/MD.svg"
    },
    {
        "name": "Montenegro",
        "code": "ME",
        "image": "./images/country_flags/ME.svg"
    },
    {
        "name": "St. Martin",
        "code": "MF",
        "image": "./images/country_flags/MF.svg"
    },
    {
        "name": "Madagascar",
        "code": "MG",
        "image": "./images/country_flags/MG.svg"
    },
    {
        "name": "Marshall Islands",
        "code": "MH",
        "image": "./images/country_flags/MH.svg"
    },
    {
        "name": "North Macedonia",
        "code": "MK",
        "image": "./images/country_flags/MK.svg"
    },
    {
        "name": "Mali",
        "code": "ML",
        "image": "./images/country_flags/ML.svg"
    },
    {
        "name": "Myanmar (Burma)",
        "code": "MM",
        "image": "./images/country_flags/MM.svg"
    },
    {
        "name": "Mongolia",
        "code": "MN",
        "image": "./images/country_flags/MN.svg"
    },
    {
        "name": "Macao SAR China",
        "code": "MO",
        "image": "./images/country_flags/MO.svg"
    },
    {
        "name": "Northern Mariana Islands",
        "code": "MP",
        "image": "./images/country_flags/MP.svg"
    },
    {
        "name": "Martinique",
        "code": "MQ",
        "image": "./images/country_flags/MQ.svg"
    },
    {
        "name": "Mauritania",
        "code": "MR",
        "image": "./images/country_flags/MR.svg"
    },
    {
        "name": "Montserrat",
        "code": "MS",
        "image": "./images/country_flags/MS.svg"
    },
    {
        "name": "Malta",
        "code": "MT",
        "image": "./images/country_flags/MT.svg"
    },
    {
        "name": "Mauritius",
        "code": "MU",
        "image": "./images/country_flags/MU.svg"
    },
    {
        "name": "Maldives",
        "code": "MV",
        "image": "./images/country_flags/MV.svg"
    },
    {
        "name": "Malawi",
        "code": "MW",
        "image": "./images/country_flags/MW.svg"
    },
    {
        "name": "Mexico",
        "code": "MX",
        "image": "./images/country_flags/MX.svg"
    },
    {
        "name": "Malaysia",
        "code": "MY",
        "image": "./images/country_flags/MY.svg"
    },
    {
        "name": "Mozambique",
        "code": "MZ",
        "image": "./images/country_flags/MZ.svg"
    },
    {
        "name": "Namibia",
        "code": "NA",
        "image": "./images/country_flags/NA.svg"
    },
    {
        "name": "New Caledonia",
        "code": "NC",
        "image": "./images/country_flags/NC.svg"
    },
    {
        "name": "Niger",
        "code": "NE",
        "image": "./images/country_flags/NE.svg"
    },
    {
        "name": "Norfolk Island",
        "code": "NF",
        "image": "./images/country_flags/NF.svg"
    },
    {
        "name": "Nigeria",
        "code": "NG",
        "image": "./images/country_flags/NG.svg"
    },
    {
        "name": "Nicaragua",
        "code": "NI",
        "image": "./images/country_flags/NI.svg"
    },
    {
        "name": "Netherlands",
        "code": "NL",
        "image": "./images/country_flags/NL.svg"
    },
    {
        "name": "Norway",
        "code": "NO",
        "image": "./images/country_flags/NO.svg"
    },
    {
        "name": "Nepal",
        "code": "NP",
        "image": "./images/country_flags/NP.svg"
    },
    {
        "name": "Nauru",
        "code": "NR",
        "image": "./images/country_flags/NR.svg"
    },
    {
        "name": "Niue",
        "code": "NU",
        "image": "./images/country_flags/NU.svg"
    },
    {
        "name": "New Zealand",
        "code": "NZ",
        "image": "./images/country_flags/NZ.svg"
    },
    {
        "name": "Oman",
        "code": "OM",
        "image": "./images/country_flags/OM.svg"
    },
    {
        "name": "Panama",
        "code": "PA",
        "image": "./images/country_flags/PA.svg"
    },
    {
        "name": "Peru",
        "code": "PE",
        "image": "./images/country_flags/PE.svg"
    },
    {
        "name": "French Polynesia",
        "code": "PF",
        "image": "./images/country_flags/PF.svg"
    },
    {
        "name": "Papua New Guinea",
        "code": "PG",
        "image": "./images/country_flags/PG.svg"
    },
    {
        "name": "Philippines",
        "code": "PH",
        "image": "./images/country_flags/PH.svg"
    },
    {
        "name": "Pakistan",
        "code": "PK",
        "image": "./images/country_flags/PK.svg"
    },
    {
        "name": "Poland",
        "code": "PL",
        "image": "./images/country_flags/PL.svg"
    },
    {
        "name": "St. Pierre & Miquelon",
        "code": "PM",
        "image": "./images/country_flags/PM.svg"
    },
    {
        "name": "Pitcairn Islands",
        "code": "PN",
        "image": "./images/country_flags/PN.svg"
    },
    {
        "name": "Puerto Rico",
        "code": "PR",
        "image": "./images/country_flags/PR.svg"
    },
    {
        "name": "Palestinian Territories",
        "code": "PS",
        "image": "./images/country_flags/PS.svg"
    },
    {
        "name": "Portugal",
        "code": "PT",
        "image": "./images/country_flags/PT.svg"
    },
    {
        "name": "Palau",
        "code": "PW",
        "image": "./images/country_flags/PW.svg"
    },
    {
        "name": "Paraguay",
        "code": "PY",
        "image": "./images/country_flags/PY.svg"
    },
    {
        "name": "Qatar",
        "code": "QA",
        "image": "./images/country_flags/QA.svg"
    },
    {
        "name": "Réunion",
        "code": "RE",
        "image": "./images/country_flags/RE.svg"
    },
    {
        "name": "Romania",
        "code": "RO",
        "image": "./images/country_flags/RO.svg"
    },
    {
        "name": "Serbia",
        "code": "RS",
        "image": "./images/country_flags/RS.svg"
    },
    {
        "name": "Russia",
        "code": "RU",
        "image": "./images/country_flags/RU.svg"
    },
    {
        "name": "Rwanda",
        "code": "RW",
        "image": "./images/country_flags/RW.svg"
    },
    {
        "name": "Saudi Arabia",
        "code": "SA",
        "image": "./images/country_flags/SA.svg"
    },
    {
        "name": "Solomon Islands",
        "code": "SB",
        "image": "./images/country_flags/SB.svg"
    },
    {
        "name": "Seychelles",
        "code": "SC",
        "image": "./images/country_flags/SC.svg"
    },
    {
        "name": "Sudan",
        "code": "SD",
        "image": "./images/country_flags/SD.svg"
    },
    {
        "name": "Sweden",
        "code": "SE",
        "image": "./images/country_flags/SE.svg"
    },
    {
        "name": "Singapore",
        "code": "SG",
        "image": "./images/country_flags/SG.svg"
    },
    {
        "name": "St. Helena",
        "code": "SH",
        "image": "./images/country_flags/SH.svg"
    },
    {
        "name": "Slovenia",
        "code": "SI",
        "image": "./images/country_flags/SI.svg"
    },
    {
        "name": "Svalbard & Jan Mayen",
        "code": "SJ",
        "image": "./images/country_flags/SJ.svg"
    },
    {
        "name": "Slovakia",
        "code": "SK",
        "image": "./images/country_flags/SK.svg"
    },
    {
        "name": "Sierra Leone",
        "code": "SL",
        "image": "./images/country_flags/SL.svg"
    },
    {
        "name": "San Marino",
        "code": "SM",
        "image": "./images/country_flags/SM.svg"
    },
    {
        "name": "Senegal",
        "code": "SN",
        "image": "./images/country_flags/SN.svg"
    },
    {
        "name": "Somalia",
        "code": "SO",
        "image": "./images/country_flags/SO.svg"
    },
    {
        "name": "Suriname",
        "code": "SR",
        "image": "./images/country_flags/SR.svg"
    },
    {
        "name": "South Sudan",
        "code": "SS",
        "image": "./images/country_flags/SS.svg"
    },
    {
        "name": "São Tomé & Príncipe",
        "code": "ST",
        "image": "./images/country_flags/ST.svg"
    },
    {
        "name": "El Salvador",
        "code": "SV",
        "image": "./images/country_flags/SV.svg"
    },
    {
        "name": "Sint Maarten",
        "code": "SX",
        "image": "./images/country_flags/SX.svg"
    },
    {
        "name": "Syria",
        "code": "SY",
        "image": "./images/country_flags/SY.svg"
    },
    {
        "name": "Eswatini",
        "code": "SZ",
        "image": "./images/country_flags/SZ.svg"
    },
    {
        "name": "Tristan da Cunha",
        "code": "TA",
        "image": "./images/country_flags/TA.svg"
    },
    {
        "name": "Turks & Caicos Islands",
        "code": "TC",
        "image": "./images/country_flags/TC.svg"
    },
    {
        "name": "Chad",
        "code": "TD",
        "image": "./images/country_flags/TD.svg"
    },
    {
        "name": "French Southern Territories",
        "code": "TF",
        "image": "./images/country_flags/TF.svg"
    },
    {
        "name": "Togo",
        "code": "TG",
        "image": "./images/country_flags/TG.svg"
    },
    {
        "name": "Thailand",
        "code": "TH",
        "image": "./images/country_flags/TH.svg"
    },
    {
        "name": "Tajikistan",
        "code": "TJ",
        "image": "./images/country_flags/TJ.svg"
    },
    {
        "name": "Tokelau",
        "code": "TK",
        "image": "./images/country_flags/TK.svg"
    },
    {
        "name": "Timor-Leste",
        "code": "TL",
        "image": "./images/country_flags/TL.svg"
    },
    {
        "name": "Turkmenistan",
        "code": "TM",
        "image": "./images/country_flags/TM.svg"
    },
    {
        "name": "Tunisia",
        "code": "TN",
        "image": "./images/country_flags/TN.svg"
    },
]



  init__select();

// Select
function init__select(){

    let select = document.querySelector('#options_div');
    jsonData.map(item=>{
        // let option = document.createElement('option');
        // option.value = item.code;
        // option.innerText = item.code;

        let singleOption = document.createElement(`div`);
        
        // add image
        let img = document.createElement(`img`);
        img.setAttribute('src', item.image)
        // singleOption.setAttribute('class', "option")
        singleOption.className = "option"
        singleOption.value = "item?.code"
        singleOption.setAttribute('value', item.code)
        singleOption.setAttribute('data-image', item.image)
        
        singleOption.textContent = item.code
        singleOption.appendChild(img);
        
        select.appendChild(singleOption);
    })


	let selects = document.querySelectorAll('.select');
	let options = document.querySelectorAll('.option');
	let exist_open_select = document.querySelector('.select.open');
	let exist_open_parent = document.querySelector('.select-group.open');

	// Open Select with toggle class open
	selects.forEach(select => {
		select.addEventListener('click', e => {
			exist_open_select = document.querySelector('.select.open');
			exist_open_select ? exist_open_parent = exist_open_select.closest('.select-group.open') : null ;

			// If Select Already Contains Open, Remove
			if(e.target.closest('.select').classList.contains('open')){
				e.target.closest('.select').classList.remove('open');
				e.target.closest('.select-group').classList.remove('open');
			} else {
				e.target.closest('.select').classList.add('open');
				e.target.closest('.select-group').classList.add('open');
			}

			// [Multiple Selects] Remove Previous Open Selects
			exist_open_select ? exist_open_select.classList.remove('open') : null;
			exist_open_select ? exist_open_parent.classList.remove('open') : null;
		});
	});
	

	// INIT: Check if option selected from init
	let options_init_selected = document.querySelectorAll('.option[aria-selected="true"]');
	if(options_init_selected.length > 0){
		// console.log(options_init_selected);

		options_init_selected.forEach(option => {
			let dft_active_value 	= option.attributes.value.value;
			let dft_active_label 	= option.innerText;
			let dft_parent 			= option.closest('.select');
			console.log(dft_active_value, dft_active_label);
			dft_parent.querySelector('input[type=hidden]').setAttribute('value', dft_active_value);
			dft_parent.querySelector('input[type=text]').setAttribute('value', dft_active_label);
		})
	}

	// Update Selected Value
	options.forEach(option => {
        
		option.addEventListener('click', e => {
			e.stopPropagation();
			let this_select 		= e.target.closest('.select');
			let this_input 			= this_select.querySelector('input[type="text"]');
			let this_input__hidden 	= this_select.querySelector('input[type="hidden"]');

			///////////////////////////////////////////
			//////// Execute These After Click ////////
			///////////////////////////////////////////
			// Remove Previous Active Option
			let alreadyActiveOption = this_select.querySelector('.option.active');
			alreadyActiveOption ? alreadyActiveOption.classList.remove('active')  : null;
			alreadyActiveOption ? alreadyActiveOption.removeAttribute('aria-selected') : null;

			// Add Active Option
			e.target.classList.add('active');
			e.target.setAttribute('aria-selected',true);

			// Update Value
            // create element
            let selected_country =  document.querySelector(`.selected_country img`);
            selected_country.setAttribute('src', e.target.attributes['data-image'].value);
			this_input.setAttribute('value', e.target.innerText);
			this_input__hidden.setAttribute('value', e.target.attributes.value.value);

			console.log(e.target.attributes.value.value, e.target.innerText)

			// Close Select Options
			exist_open_select.classList.remove('open');
			exist_open_parent.classList.remove('open');
		});
	});

	// Close if click outside select
	document.addEventListener('click', e => {
		// Check if exist open select
		exist_open_select = document.querySelector('.select.open');
		exist_open_select ? exist_open_parent = exist_open_select.closest('.select-group.open') : null ;
		if(exist_open_select){

			// Check if Target is inside select
			let isSelect = exist_open_select.contains(e.target);
			isSelect ? null : exist_open_select.classList.remove('open');
			isSelect ? null : exist_open_parent.classList.remove('open');
		}
	})
}


// sidebar 
var menuAdd = document.querySelector('#menuHemburger');
var close = document.querySelector('.close')

menuAdd.addEventListener('click', function () {
  var sidebar = document.querySelector('#sidebar');
  sidebar.classList.add('active');

});

close.addEventListener('click', function () {
    var sidebar = document.querySelector('#sidebar');
    sidebar.classList.remove('active');
  
  });

